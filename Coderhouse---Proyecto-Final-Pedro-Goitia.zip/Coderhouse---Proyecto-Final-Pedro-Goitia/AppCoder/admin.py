from django.contrib import admin
from AppCoder.models import *


admin.site.register(ObjetoVenta)
